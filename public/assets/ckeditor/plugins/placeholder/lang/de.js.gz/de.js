/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","de",{placeholder:{title:"Platzhalter Einstellungen",toolbar:"Platzhalter erstellen",text:"Platzhalter Text",edit:"Platzhalter bearbeiten",textMissing:"Der Platzhalter muss einen Text beinhalten."}});